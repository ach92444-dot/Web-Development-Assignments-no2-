const allQuestions = [
  {q:"Which HTML element is used to create a hyperlink?", options:["<link>","<a>","<href>","<url>"], answer:1},
  {q:"Which CSS property changes the text color?", options:["font-color","text-style","color","foreground"], answer:2},
  {q:"Which Bootstrap class creates a responsive fixed-width container?", options:[".box","container","responsive",".fixed"], answer:1},
  {q:"Which JavaScript keyword declares a block-scoped variable?", options:["var","let","define","dim"], answer:1},
  {q:"What does CSS media query mainly help with?", options:["Database storage","Responsive layouts","Server hosting","File compression"], answer:1},
  {q:"Which HTML attribute provides alternative text for an image?", options:["title","src","alt","caption"], answer:2},
  {q:"Which JavaScript method selects an element by its id?", options:["getElementById()","selectId()","queryId()","findId()"], answer:0},
  {q:"In Bootstrap, which class is commonly used for a primary button?", options:["btn-main","button-primary","btn btn-primary","primary-btn"], answer:2}
];

let questions=[], current=0, score=0, selected=false, seconds=120, timerId, startedAt;

const $ = id => document.getElementById(id);
function shuffle(a){ return [...a].sort(()=>Math.random()-.5); }

function startQuiz(){
  questions = shuffle(allQuestions).slice(0,5);
  current=0; score=0; selected=false; seconds=120; startedAt=Date.now();
  $("quizScreen").classList.remove("hidden"); $("resultScreen").classList.add("hidden");
  clearInterval(timerId); timerId=setInterval(tick,1000);
  render();
}
function tick(){
  seconds--;
  updateTimer();
  if(seconds<=0){ seconds=0; updateTimer(); finishQuiz(); }
}
function updateTimer(){
  const m=String(Math.floor(seconds/60)).padStart(2,"0"), s=String(seconds%60).padStart(2,"0");
  $("timer").textContent=`${m}:${s}`;
  if(seconds<=20) $("timer").style.color="var(--danger)";
}
function render(){
  const item=questions[current];
  $("progressText").textContent=`Question ${current+1} of ${questions.length}`;
  $("scoreText").textContent=`Score: ${score}`;
  $("feedback").textContent=""; $("feedback").className="feedback";
  $("nextBtn").disabled=true; selected=false;
  $("segmentedBar").innerHTML=questions.map((_,i)=>{
    const state=i<current ? (questions[i].picked===questions[i].answer?"correct":"wrong") : i===current?"current":"";
    return `<span class="seg ${state}"></span>`;
  }).join("");
  $("questionArea").innerHTML=`
    <div class="question-number">QUESTION ${current+1}</div>
    <h2 class="question">${item.q}</h2>
    <div class="options">${item.options.map((op,i)=>`<button class="option" data-index="${i}" type="button">${op}</button>`).join("")}</div>
  `;
  document.querySelectorAll(".option").forEach(btn=>btn.addEventListener("click",()=>choose(+btn.dataset.index)));
}
function choose(index){
  if(selected) return;
  selected=true;
  const item=questions[current]; item.picked=index;
  document.querySelectorAll(".option").forEach((btn,i)=>{
    btn.disabled=true;
    if(i===item.answer) btn.classList.add("correct");
    if(i===index && index!==item.answer) btn.classList.add("wrong");
  });
  if(index===item.answer){score++; $("feedback").textContent="Correct! Nice work."; $("feedback").className="feedback ok";}
  else {$("feedback").textContent=`Not quite. Correct answer: ${item.options[item.answer]}`; $("feedback").className="feedback bad";}
  $("scoreText").textContent=`Score: ${score}`; $("nextBtn").disabled=false;
}
$("nextBtn").addEventListener("click",()=>{
  if(!selected) return;
  current++;
  if(current>=questions.length) finishQuiz(); else render();
});
function finishQuiz(){
  clearInterval(timerId);
  $("quizScreen").classList.add("hidden"); $("resultScreen").classList.remove("hidden");
  $("finalScore").textContent=score; $("correctCount").textContent=score;
  $("percentage").textContent=Math.round(score/questions.length*100)+"%";
  $("timeUsed").textContent=Math.round((Date.now()-startedAt)/1000)+"s";
  $("resultTitle").textContent=score>=4?"Excellent result!":score>=3?"Good job!":"Keep practicing!";
}
$("restartBtn").addEventListener("click",startQuiz);
$("themeBtn").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  $("themeBtn").textContent=document.body.classList.contains("dark")?"☀":"☾";
});
$("downloadBtn").addEventListener("click",()=>{
  const lines=[
    "QUIZORA - QUIZ RESULTS","CSC336 Web Technologies","",
    `Score: ${score}/${questions.length}`,
    `Percentage: ${Math.round(score/questions.length*100)}%`,
    `Time used: ${Math.round((Date.now()-startedAt)/1000)} seconds`,"",
    "Question Summary:"
  ];
  questions.forEach((x,i)=>lines.push(`${i+1}. ${x.q}`,`Answer: ${x.options[x.picked]}`,`Result: ${x.picked===x.answer?"Correct":"Incorrect"}`,""));
  const blob=new Blob([lines.join("\n")],{type:"application/pdf"});
  const url=URL.createObjectURL(blob), a=document.createElement("a");
  a.href=url; a.download="Quizora_Results.pdf"; a.click(); URL.revokeObjectURL(url);
});
startQuiz();
